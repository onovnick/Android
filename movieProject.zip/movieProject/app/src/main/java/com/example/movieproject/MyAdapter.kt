package com.example.movieproject
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(
    var c: Context,
    var models: ArrayList<Model>
) : RecyclerView.Adapter<Myholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Myholder {
        val view:Context = LayoutInflater.from(parent.context).inflate(R.layout.row,parent,false)

        return null
    }

    override fun onBindViewHolder(holder: Myholder, position: Int) {
        myHolder.mTitle.setText(models[i].title)
        myHolder.mDes.setText(models[i].description)
        myHolder.mImageView(models[i].getImg)
    }

    override fun getItemCount(): Int {
        return models.size
    }

}