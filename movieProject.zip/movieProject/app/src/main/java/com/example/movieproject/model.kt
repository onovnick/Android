package com.example.movieproject

class Model {
    var title: String? = null
    var description: String? = null
    var img = 0

}