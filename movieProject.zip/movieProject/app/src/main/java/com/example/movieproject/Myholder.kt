package com.example.movieproject

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView

class Myholder : RecyclerView.ViewHolder {
    var mImageView: ImageView
    var mTitle: TextView
    var mDes:TextView
    constructor(@NonNull itemView: View) : super(itemView) {
        this.mImageView = itemView.findViewById(R.id.ImageIv)
        this.mTitle = itemView.findViewById(R.id.titleTv)
        this.mDes = itemView.findViewById(R.id.despriptionTv)



    }
}