package com.example.movieproject


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(
    var c: ArrayList<Model>,
    var models: ArrayList<Model>
) : RecyclerView.Adapter<MyAdapter.MyHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view:Context = LayoutInflater.from(parent.context).inflate(R.layout.row,parent,false)

        return MyHolder(view)
    }

    override fun onBindViewHolder(holder: MyHolder, i: Int) {
        myHolder.mTitle.setText(models[i].title)
        myHolder.mDes.setText(models[i].description)
        myHolder.mImageView(models[i].img)
    }

    override fun getItemCount(): Int {
        return models.size
    }

    class MyHolder : RecyclerView.ViewHolder {
        var mImageView: ImageView
        var mTitle: TextView
        var mDes: TextView
        constructor(@NonNull itemView: View) : super(itemView) {
            this.mImageView = itemView.findViewById(R.id.ImageIv)
            this.mTitle = itemView.findViewById(R.id.titleTv)
            this.mDes = itemView.findViewById(R.id.despriptionTv)
        }


    }
}