package com.example.movieproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import android.widget.LinearLayout


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    val recyclerView = findViewById(R.id.recycleView) as RecyclerView
    val adapter = MyAdapter(models)
    mRecyclerView.setLayoverManager(LinearLayoutManager(this))
    val models = ArrayList<Model>()
    mRecyclerView.adapter = adapter


    //adding some dummy data to the list


}
